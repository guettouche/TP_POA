package fiche2.classes;

public class D {
    private int i;
    
    public D(int x) {
        i = x;
    }
    
    @Override
    public String toString() {
        return "D(" + i + ")";
    }
}
